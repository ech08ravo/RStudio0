## Submission info

New submission: Package was archived on CRAN
Archived on 2018-05-03 as check problems were not corrected despite reminders.
I have now corrected the relevant parts.

## Test environments
* windows 10 (local dektop), R 3.5.0
* ubuntu 14.04 (travis-ci), R 3.4.2
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

There are no reverse dependencies.

